// ------------------------------------------------------------
// feedCategories.js — Phase 4.4 (v1.141 Crypto Stable)
// ------------------------------------------------------------

export const feedCategories = {
  // ------------------------------------------------------------
  // CRYPTO (v1.141)
  // ------------------------------------------------------------
  crypto: [
    { name: "ct", label: "CoinTelegraph" },
    { name: "decrypt", label: "Decrypt" },
    { name: "cryptopanic", label: "CryptoPanic" },
    { name: "yf_crypto", label: "Yahoo Crypto" },
    { name: "cg_crypto", label: "CoinGecko" },
    { name: "cb_eng", label: "Coinbase Engineering" }
  ],

  // ------------------------------------------------------------
  // FINANCE (v1.142)
  // ------------------------------------------------------------
  finance: [
    { name: "marketwatch", label: "MarketWatch" },
    { name: "investopedia", label: "Investopedia" },
    { name: "seeking_alpha", label: "Seeking Alpha" }
  ],

  // ------------------------------------------------------------
  // NEWS (v1.143)
  // ------------------------------------------------------------
  news: [
    { name: "reuters_world", label: "Reuters" },
    { name: "bbc_world", label: "BBC World" },
    { name: "ap_world", label: "AP News" }
  ],

  // ------------------------------------------------------------
  // JAVA (v1.144)
  // ------------------------------------------------------------
  java: [
    { name: "jcg", label: "Java Code Geeks" },
    { name: "infoq_java", label: "InfoQ Java" }
  ],

  // ------------------------------------------------------------
  // SECURITY (v1.145)
  // ------------------------------------------------------------
  security: [
    { name: "dark_reading", label: "Dark Reading" },
    { name: "security_week", label: "SecurityWeek" },
    { name: "krebs", label: "Krebs on Security" }
  ],

  // ------------------------------------------------------------
  // IoT (v1.146)
  // ------------------------------------------------------------
  iot: [
    { name: "iot_world", label: "IoT World Today" },
    { name: "stacey_iot", label: "Stacey on IoT" },
    { name: "iot_business", label: "IoT Business News" }
  ],

  // ------------------------------------------------------------
  // SPRING (v1.147)
  // ------------------------------------------------------------
  spring: [
    { name: "spring_blog", label: "Spring Blog" },
    { name: "spring_guides", label: "Spring Guides" }
  ],

  // ------------------------------------------------------------
  // AWS (v1.148)
  // ------------------------------------------------------------
  aws: [
    { name: "aws_news", label: "AWS News" },
    { name: "aws_arch", label: "AWS Architecture" },
    { name: "aws_security", label: "AWS Security" }
  ],

  // ------------------------------------------------------------
  // REACT (v1.149)
  // ------------------------------------------------------------
  react: [
    { name: "react_status", label: "React Status" },
    { name: "logrocket_react", label: "LogRocket React" },
    { name: "smashing_react", label: "Smashing React" }
  ],

  // ------------------------------------------------------------
  // SPORTS (v1.1410)
  // ------------------------------------------------------------
  sports: [
    { name: "espn", label: "ESPN" },
    { name: "cbs_sports", label: "CBS Sports" },
    { name: "bleacher", label: "Bleacher Report" }
  ],

  // ------------------------------------------------------------
  // UNAVAILABLE (Fallback-only feeds)
  // ------------------------------------------------------------
  unavailable: [
    { name: "cb", label: "Coinbase Blog (Fallback)" },
    { name: "binance_blog", label: "Binance Blog (Fallback)" },
    { name: "kraken_blog", label: "Kraken Blog (Fallback)" },
    { name: "rh_crypto", label: "Robinhood Crypto (Fallback)" }
  ]
};
