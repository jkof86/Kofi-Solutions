// ------------------------------------------------------------
// feedsMap.js — v1.141 (Crypto Stable + Unavailable Grouping)
// ------------------------------------------------------------
//
// This map defines ALL feeds used by the backend router.
// Keys must match feedCategories.js and the frontend.
// Values determine how the backend handles each feed:
//
//   - "https://..." → RSS feed (handled by handleRss)
//   - "json:<key>"  → JSON feed (handled by JSON handlers)
//   - "fallback:<key>" → Unavailable feed (Cloudflare/auth)
//
// ------------------------------------------------------------

export const FEEDS = {
  // ------------------------------------------------------------
  // CRYPTO (Active Feeds) — v1.141
  // ------------------------------------------------------------

  // CoinTelegraph — RSS
  ct: "https://cointelegraph.com/rss",

  // Decrypt — RSS
  decrypt: "https://decrypt.co/feed",

  // CryptoPanic — JSON API (requires API key)
  cryptopanic: "json:cryptopanic_crypto",

  // Yahoo Finance Crypto — JSON API
  yf_crypto: "json:yahoo_crypto",

  // CoinGecko — JSON status updates
  cg_crypto: "json:coingecko_crypto",

  // Coinbase Engineering — RSS
  cb_eng: "https://blog.coinbase.com/engineering/rss/",


  // ------------------------------------------------------------
  // FINANCE — v1.142 (future)
  // ------------------------------------------------------------
  marketwatch: "https://www.marketwatch.com/rss/topstories",
  investopedia: "https://www.investopedia.com/feedbuilder/feed/",
  seeking_alpha: "https://seekingalpha.com/market_currents.xml",


  // ------------------------------------------------------------
  // NEWS — v1.143 (future)
  // ------------------------------------------------------------
  reuters_world: "https://feeds.reuters.com/Reuters/worldNews",
  bbc_world: "http://feeds.bbci.co.uk/news/world/rss.xml",
  ap_world: "https://rss.apnews.com/apf-intlnews",


  // ------------------------------------------------------------
  // JAVA — v1.144 (future)
  // ------------------------------------------------------------
  jcg: "https://www.javacodegeeks.com/feed",
  infoq_java: "https://feed.infoq.com/java",


  // ------------------------------------------------------------
  // SECURITY — v1.145 (future)
  // ------------------------------------------------------------
  dark_reading: "https://www.darkreading.com/rss.xml",
  security_week: "https://feeds.feedburner.com/Securityweek",
  krebs: "https://krebsonsecurity.com/feed/",


  // ------------------------------------------------------------
  // IoT — v1.146 (future)
  // ------------------------------------------------------------
  iot_world: "https://www.iotworldtoday.com/feed",
  stacey_iot: "https://staceyoniot.com/feed",
  iot_business: "https://iotbusinessnews.com/feed/",


  // ------------------------------------------------------------
  // SPRING — v1.147 (future)
  // ------------------------------------------------------------
  spring_blog: "https://spring.io/blog.atom",
  spring_guides: "https://spring.io/guides.atom",


  // ------------------------------------------------------------
  // AWS — v1.148 (future)
  // ------------------------------------------------------------
  aws_news: "https://aws.amazon.com/about-aws/whats-new/recent/feed/",
  aws_arch: "https://aws.amazon.com/blogs/architecture/feed/",
  aws_security: "https://aws.amazon.com/blogs/security/feed/",


  // ------------------------------------------------------------
  // REACT — v1.149 (future)
  // ------------------------------------------------------------
  react_status: "https://react.statuscode.com/feed",
  logrocket_react: "https://blog.logrocket.com/tag/react/feed/",
  smashing_react: "https://www.smashingmagazine.com/tag/react/feed/",


  // ------------------------------------------------------------
  // SPORTS — v1.1410 (future)
  // ------------------------------------------------------------
  espn: "https://www.espn.com/espn/rss/news",
  cbs_sports: "https://www.cbssports.com/rss/headlines/",
  bleacher: "https://bleacherreport.com/articles/feed",


  // ------------------------------------------------------------
  // UNAVAILABLE (Fallback‑Only Feeds)
  // ------------------------------------------------------------

  // Coinbase Blog — Cloudflare protected
  cb: "fallback:coinbase_blog",

  // Binance Blog — Cloudflare protected
  binance_blog: "fallback:binance_blog",

  // Kraken Blog — Cloudflare protected
  kraken_blog: "fallback:kraken_blog",

  // Robinhood Crypto — API now requires auth
  rh_crypto: "fallback:robinhood_crypto"
};
