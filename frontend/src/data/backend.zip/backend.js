// ------------------------------------------------------------
// backend.js — v1.141 (Crypto stable + Unavailable grouping)
// ------------------------------------------------------------

import { FEEDS } from "./src/data/feedsMap.js";
// adjust path/name as needed

// Helper: JSON response wrapper
function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify(body)
  };
}

// ------------------------------------------------------------
// Generic RSS handler
// ------------------------------------------------------------
async function handleRss(url) {
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/rss+xml, application/xml, text/xml;q=0.9,*/*;q=0.8"
      }
    });

    const text = await res.text();

    // Very lightweight RSS/Atom parsing hint: delegate to existing parser in your stack
    // Here we assume you already have parseFeed(text) somewhere.
    const items = await parseFeed(text); // <-- plug your existing parser here

    if (!items || items.length === 0) {
      return jsonResponse(200, {
        status: "error",
        error: "Feed returned HTML but no recognizable RSS/Atom entries",
        items: []
      });
    }

    return jsonResponse(200, { status: "ok", items });
  } catch (err) {
    return jsonResponse(200, {
      status: "error",
      error: "RSS exception: " + err.message,
      items: []
    });
  }
}

// ------------------------------------------------------------
// Fallback handler (for Cloudflare/auth-blocked feeds)
// ------------------------------------------------------------
async function handleFallback(feedKey) {
  // You can expand this to hit archived snapshots or static JSON if desired.
  return jsonResponse(200, {
    status: "error",
    error: `Feed "${feedKey}" is currently unavailable (fallback mode).`,
    items: []
  });
}

// ------------------------------------------------------------
// CryptoPanic JSON handler
// ------------------------------------------------------------

const CRYPTOPANIC_TOKEN = "YOUR_CRYPTOPANIC_TOKEN"; // TODO: inject via env var

async function handleCryptoPanic() {
  try {
    const url =
      `https://cryptopanic.com/api/v1/posts/?auth_token=${CRYPTOPANIC_TOKEN}&public=true`;

    const res = await fetch(url, {
      headers: {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0"
      }
    });

    const json = await res.json();

    if (!json.results || json.results.length === 0) {
      return jsonResponse(200, {
        status: "error",
        error: "CryptoPanic returned no items",
        items: []
      });
    }

    const items = json.results.map(post => ({
      title: post.title,
      url: post.url,
      summary: post.domain || "",
      content_html: post.title,
      date_published: post.published_at,
      image: null
    }));

    return jsonResponse(200, { status: "ok", items });
  } catch (err) {
    return jsonResponse(200, {
      status: "error",
      error: "CryptoPanic exception: " + err.message,
      items: []
    });
  }
}

// ------------------------------------------------------------
// Yahoo Finance Crypto JSON handler
// ------------------------------------------------------------
async function handleYahooCrypto() {
  try {
    // Example endpoint; adjust if you already have a working one
    const res = await fetch(
      "https://query1.finance.yahoo.com/v7/finance/news?category=cryptocurrency",
      {
        headers: {
          "Accept": "application/json",
          "User-Agent": "Mozilla/5.0"
        }
      }
    );

    const json = await res.json();

    const results = json?.data || json?.items || json?.articles || [];

    if (!results || results.length === 0) {
      return jsonResponse(200, {
        status: "error",
        error: "Yahoo Crypto returned no items",
        items: []
      });
    }

    const items = results.map(item => ({
      title: item.title,
      url: item.link || item.url,
      summary: item.summary || "",
      content_html: item.summary || "",
      date_published: item.pubDate || item.published_at || null,
      image:
        item.thumbnail?.resolutions?.[0]?.url ||
        item.main_image_url ||
        null
    }));

    return jsonResponse(200, { status: "ok", items });
  } catch (err) {
    return jsonResponse(200, {
      status: "error",
      error: "Yahoo Crypto exception: " + err.message,
      items: []
    });
  }
}

// ------------------------------------------------------------
// CoinGecko Crypto JSON handler (status updates)
// ------------------------------------------------------------
async function handleCoinGeckoCrypto() {
  try {
    const res = await fetch(
      "https://api.coingecko.com/api/v3/status_updates",
      {
        headers: {
          "Accept": "application/json",
          "User-Agent": "Mozilla/5.0"
        }
      }
    );

    const json = await res.json();

    if (!json.status_updates || json.status_updates.length === 0) {
      return jsonResponse(200, {
        status: "error",
        error: "CoinGecko Crypto returned no items",
        items: []
      });
    }

    const items = json.status_updates.map(post => ({
      title: `${post.project?.name || "CoinGecko"} — ${post.category}`,
      url: post.project?.homepage || "https://coingecko.com",
      summary: post.description || "",
      content_html: post.description || "",
      date_published: post.created_at,
      image: post.project?.image?.large || null
    }));

    return jsonResponse(200, { status: "ok", items });
  } catch (err) {
    return jsonResponse(200, {
      status: "error",
      error: "CoinGecko Crypto exception: " + err.message,
      items: []
    });
  }
}

// ------------------------------------------------------------
// Router — single entry point
// ------------------------------------------------------------

export async function handleFeedRequest(feedKey) {
  const target = FEEDS[feedKey];

  if (!target) {
    return jsonResponse(404, {
      status: "error",
      error: `Unknown feed key: ${feedKey}`,
      items: []
    });
  }

  // JSON handlers
  if (typeof target === "string" && target.startsWith("json:")) {
    const jsonKey = target.slice("json:".length);

    if (jsonKey === "cryptopanic_crypto") return await handleCryptoPanic();
    if (jsonKey === "yahoo_crypto") return await handleYahooCrypto();
    if (jsonKey === "coingecko_crypto") return await handleCoinGeckoCrypto();

    return jsonResponse(200, {
      status: "error",
      error: `No JSON handler implemented for ${jsonKey}`,
      items: []
    });
  }

  // Fallback handlers
  if (typeof target === "string" && target.startsWith("fallback:")) {
    const fbKey = target.slice("fallback:".length);
    return await handleFallback(fbKey);
  }

  // RSS handlers (string URL)
  if (typeof target === "string" && /^https?:\/\//.test(target)) {
    return await handleRss(target);
  }

  return jsonResponse(200, {
    status: "error",
    error: `Unrecognized FEEDS mapping for ${feedKey}`,
    items: []
  });
}

// ------------------------------------------------------------
// Lambda entry
// ------------------------------------------------------------

export async function handler(event) {
  const feedKey =
    event?.queryStringParameters?.feed ||
    event?.pathParameters?.feed ||
    null;

  if (!feedKey) {
    return jsonResponse(400, {
      status: "error",
      error: "Missing 'feed' parameter",
      items: []
    });
  }

  return await handleFeedRequest(feedKey);
}

// ------------------------------------------------------------
// Health Handler
// ------------------------------------------------------------

async function handleHealth() {
  const entries = await Promise.all(
    Object.entries(FEEDS).map(async ([key, url]) => {
      try {
        const res = await fetch(url, { method: "HEAD" },
          {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
          });
        return [key, res.ok ? "ok" : "error:" + res.status];
      } catch {
        return [key, "error"];
      }
    })
  );

  const status = {};
  for (const [k, v] of entries) status[k] = v;

  return jsonResponse(200, { status: "ok", feeds: status });
}

// ------------------------------------------------------------
// Market Handler
// ------------------------------------------------------------

async function handleMarket(symbol) {
  const cgId = SYMBOL_TO_COINGECKO[symbol];

  if (!cgId) {
    return jsonResponse(400, {
      status: "error",
      error: "Unknown symbol"
    });
  }

  const url =
    "https://api.coingecko.com/api/v3/coins/" +
    cgId +
    "/market_chart?vs_currency=usd&days=1";

  try {
    const res = await fetch(url,
      {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
      });

    if (!res.ok) {
      return jsonResponse(res.status, {
        status: "error",
        error: "CoinGecko error"
      });
    }

    return jsonResponse(200, {
      status: "ok",
      data: await res.json()
    });

  } catch (err) {
    return jsonResponse(502, {
      status: "error",
      error: err.message
    });
  }
}

// ------------------------------------------------------------
// Main Handler — Phase 4.4 Unified Router
// ------------------------------------------------------------
exports.handler = async (event) => {
  try {
    // Preflight
    if (event.httpMethod === "OPTIONS") {
      return jsonResponse(200, { status: "ok" });
    }

    const qs = event.queryStringParameters || {};
    const mode = qs.mode || "rss";
    const source = qs.source || null;

    // Mode routing
    if (mode === "health") return await handleHealth();
    if (mode === "market") return await handleMarket(qs.symbol);

    // Feed routing
    if (!source || !FEEDS[source]) {
      return jsonResponse(400, {
        status: "error",
        error: "Unknown or missing source",
        items: []
      });
    }

    const feedUrl = FEEDS[source];

    // Fallback feeds (Coinbase Blog)
    if (feedUrl.startsWith("fallback:")) {
      return jsonResponse(200, {
        status: "error",
        error: "Feed is protected or unavailable: " + source,
        items: [
          buildHtmlFallbackItem(
            "https://blog.coinbase.com/",
            "<title>Coinbase Blog Unavailable</title>",
            source
          )
        ]
      });
    }

    // JSON feeds
    if (feedUrl.startsWith("json:")) {
      const key = feedUrl.replace("json:", "");

      if (key === "robinhood_crypto") return await handleRobinhoodCrypto();
      if (key === "yahoo_crypto") return await handleYahooCrypto();
      if (key === "coingecko_crypto") return await handleCoinGeckoCrypto();

      return jsonResponse(400, {
        status: "error",
        error: "Unknown JSON feed: " + key,
        items: []
      });
    }

    // RSS feeds
    return await handleRss(source);

  } catch (err) {
    return jsonResponse(502, {
      status: "error",
      error: err.message
    });
  }
};

// ------------------------------------------------------------
// JSON Response Helper
// ------------------------------------------------------------
function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Methods": "GET,OPTIONS"
    },
    body: JSON.stringify(payload)
  };
}
